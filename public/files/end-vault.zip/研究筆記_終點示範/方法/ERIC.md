# ERIC

Expert Recommendations for Implementing Change：把導入策略分類的清單。

- [[Spoon 2024 醫院跌倒預防的導入策略]]
- 相關：[[導入策略]]
